$(document).ready(function(){
    window.prettyPrint && prettyPrint();
});

